// @lork/sdk — HTTP-клиент для Kozagogo API

const API_BASE = typeof window !== 'undefined'
  ? (window.__KOZAGOGA_API_URL__ || '')
  : ''

// Токен авторизации (устанавливается после логина)
let authToken = null

export function setAuthToken(token) {
  authToken = token
}

export function getAuthToken() {
  return authToken
}

async function apiRequest(method, path, body = null, params = {}) {
  const url = new URL(`${API_BASE}${path}`)
  Object.entries(params).forEach(([k, v]) => {
    if (v !== null && v !== undefined && v !== '') {
      url.searchParams.set(k, v)
    }
  })

  const headers = { 'Content-Type': 'application/json' }
  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`
  }

  const res = await fetch(url.toString(), {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  })

  const data = await res.json()
  if (!res.ok) {
    return { data: null, error: data.error || 'Request failed', count: 0 }
  }

  // Возвращаем в формате, совместимом со старым стубом
  return { data: Array.isArray(data) ? data : [data], error: null, count: Array.isArray(data) ? data.length : 1 }
}

class QueryBuilder {
  constructor(table) {
    this.table = table
    this._filters = {}
    this._order = null
    this._limit = null
    this._offset = null
    this._single = false
    this._maybeSingle = false
    this._method = 'select'
    this._insertData = null
    this._updateData = null
    this._deleteId = null
  }

  select(columns) { return this }
  eq(column, value) { this._filters[`eq_${column}`] = String(value); return this }
  neq(column, value) { this._filters[`neq_${column}`] = String(value); return this }
  gt(column, value) { this._filters[`gt_${column}`] = String(value); return this }
  gte(column, value) { this._filters[`gte_${column}`] = String(value); return this }
  lt(column, value) { this._filters[`lt_${column}`] = String(value); return this }
  lte(column, value) { this._filters[`lte_${column}`] = String(value); return this }
  ilike(column, pattern) { this._filters[`ilike_${column}`] = pattern; return this }
  order(column, { ascending = true } = {}) { this._order = `${column}.${ascending ? 'asc' : 'desc'}`; return this }
  limit(n) { this._limit = n; return this }
  offset(n) { this._offset = n; return this }
  range(s, e) { this._offset = s; this._limit = e - s + 1; return this }
  single() { this._single = true; return this }
  maybeSingle() { this._maybeSingle = true; return this }

  insert(values) {
    this._method = 'insert'
    this._insertData = Array.isArray(values) ? values : [values]
    return this
  }

  upsert(values) {
    // Простой upsert — вставка с конфликтом по id или slug
    this._method = 'insert'
    this._insertData = Array.isArray(values) ? values : [values]
    return this
  }

  update(values) {
    this._method = 'update'
    this._updateData = values
    return this
  }

  delete() {
    this._method = 'delete'
    return this
  }

  async then(resolve, reject) {
    try {
      let result

      if (this._method === 'select') {
        const params = { ...this._filters, select: '*' }
        if (this._order) params.order = this._order
        if (this._limit) params.limit = this._limit
        if (this._offset) params.offset = this._offset

        result = await apiRequest('GET', `/api/rest/v1/${this.table}`, null, params)
      } else if (this._method === 'insert') {
        result = await apiRequest('POST', `/api/rest/v1/${this.table}`, this._insertData.length === 1 ? this._insertData[0] : this._insertData)
      } else if (this._method === 'update') {
        result = await apiRequest('PUT', `/api/rest/v1/${this.table}`, { ...this._filters, ...this._updateData })
      } else if (this._method === 'delete') {
        const id = this._filters['eq_id']
        result = await apiRequest('DELETE', `/api/rest/v1/${this.table}/${id}`)
      }

      // Обработка single/maybeSingle
      if (this._single || this._maybeSingle) {
        const singleData = result.data?.[0] || null
        return resolve({ data: singleData, error: result.error, count: result.count })
      }

      return resolve(result)
    } catch (err) {
      return reject(err)
    }
  }
}

export class DbClient {
  from(table) {
    return new QueryBuilder(table)
  }
}

export const db = new DbClient()
