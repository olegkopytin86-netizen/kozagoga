export interface PostgrestResponse<T> {
  data: T[] | null;
  error: Error | null;
  count: number | null;
}

export interface PostgrestSingleResponse<T> {
  data: T | null;
  error: Error | null;
  count: number | null;
}

export interface QueryBuilder<T> {
  select(columns?: string): this;
  eq(column: string, value: unknown): this;
  neq(column: string, value: unknown): this;
  gt(column: string, value: unknown): this;
  gte(column: string, value: unknown): this;
  lt(column: string, value: unknown): this;
  lte(column: string, value: unknown): this;
  like(column: string, pattern: string): this;
  ilike(column: string, pattern: string): this;
  order(column: string, options?: { ascending?: boolean }): this;
  limit(count: number): this;
  offset(count: number): this;
  range(start: number, end: number): this;
  single(): QueryBuilderSingle<T>;
  maybeSingle(): QueryBuilderSingle<T>;
  insert(values: Record<string, unknown> | Record<string, unknown>[]): this;
  upsert(values: Record<string, unknown> | Record<string, unknown>[], options?: Record<string, unknown>): this;
  update(values: Record<string, unknown>): this;
  delete(): this;
  then<TResult1 = PostgrestResponse<T>, TResult2 = never>(
    onfulfilled?: ((value: PostgrestResponse<T>) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2>;
}

export interface QueryBuilderSingle<T> {
  eq(column: string, value: unknown): this;
  select(columns?: string): this;
  then<TResult1 = PostgrestSingleResponse<T>, TResult2 = never>(
    onfulfilled?: ((value: PostgrestSingleResponse<T>) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2>;
}

export interface DbClient {
  from<T = any>(table: string): QueryBuilder<T>;
}

export declare function setAuthToken(token: string | null): void
export declare function getAuthToken(): string | null
export declare const db: DbClient;
